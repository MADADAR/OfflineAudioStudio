package com.offlineaudiostudio

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PlayerScreen() } }
}

@Composable fun PlayerScreen() {
    val context = LocalContext.current
    var chosen by remember { mutableStateOf<Uri?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { chosen = it; player?.release(); player = MediaPlayer().apply { setDataSource(context, it); prepare() }; playing = false }
    }
    DisposableEffect(Unit) { onDispose { player?.release() } }
    MaterialTheme { Surface(Modifier.fillMaxSize()) { Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
        Text("Offline Audio Studio", style=MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(24.dp)); Text(chosen?.lastPathSegment ?: "اختر ملفًا صوتيًا من هاتفك")
        Spacer(Modifier.height(16.dp)); Button(onClick={pick.launch(arrayOf("audio/*"))}) { Text("اختيار ملف صوتي") }
        Spacer(Modifier.height(12.dp)); Button(enabled=player!=null, onClick={ val p=player; if(p!=null){ if(p.isPlaying){p.pause();playing=false}else{p.start();playing=true} } }) { Text(if(playing)"إيقاف مؤقت" else "تشغيل") }
        Spacer(Modifier.height(12.dp)); Button(enabled=player!=null,onClick={player?.let{it.stop();it.prepare();playing=false}}){Text("إيقاف وإعادة")}
    } } }
}
