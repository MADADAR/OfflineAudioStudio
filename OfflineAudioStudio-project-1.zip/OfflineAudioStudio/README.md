# OfflineAudioStudio

Starter Android app for an offline audio player. The current prototype can import audio using Android's picker and play/pause/stop it. This is not yet audio stem separation.

## APK build

GitHub Actions workflow: `.github/workflows/build-apk.yml` builds a debug APK on push or manually using **Actions → Build Android APK → Run workflow**. Download the APK from the workflow's Artifacts.
